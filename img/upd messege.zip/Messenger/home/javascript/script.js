const activeHover = (linkSelector, classSelector) => {
    const link = document.querySelectorAll(linkSelector);

    link.forEach(item => {
        item.addEventListener('click', (e) => {
            link.forEach(element => {
                if (element.classList.contains(classSelector)) {
                    element.classList.remove(classSelector);
                } else {
                    item.classList.add(classSelector);
                }
            });
        });
    });
}

activeHover('.my-contact', 'active-chat');
activeHover('.icons-footer', 'active-icon');
activeHover('.icons-contact', 'active-icon-header');
