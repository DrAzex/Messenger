// const messenger = document.querySelectorAll('.messengere-chat');

// messenger.onscroll = () => {
//     const dateBox = document.querySelectorAll('.date-top-yesterday');
//     const y = window.scrollY;

//     console.log(y);
// }